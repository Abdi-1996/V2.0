# Проверка сборки — Comfy Remote 2.0 Stage 1

Проверено перед упаковкой:

- Swift syntax parse: все `.swift` файлы проходят `swiftc -frontend -parse`.
- Python: `server.py`, `gui.py`, `corel_bridge.py` проходят `py_compile`.
- `Info.plist`: версия 2.0.0, build 11, Local Network/ATS присутствуют.
- Xcode project: MARKETING_VERSION 2.0.0, CURRENT_PROJECT_VERSION 11.
- GitHub Actions YAML корректно парсится.
- PCRemoteServer version: 6.1.0.
- Hub API: `/api/capabilities`, API version 7.
- ComfyUI открывается как отдельный модуль из Hub.
- CorelDRAW использует существующий Corel bridge как beta-модуль.
- AI Toolkit экран зарезервирован под этап 2; training API ещё не включён.

Полную runtime-сборку iOS выполняет GitHub Actions на macOS 15.
