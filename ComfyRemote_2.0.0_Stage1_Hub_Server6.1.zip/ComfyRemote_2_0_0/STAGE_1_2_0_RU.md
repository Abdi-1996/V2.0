# Comfy Remote 2.0 — Этап 1

Версия приложения: **2.0.0 build 11**  
Стабильный Windows сервер: **PCRemoteServer 6.1.0**  
Hub API: **v7**

## Что сделано

- После входа приложение больше не открывает ComfyUI сразу: появляется единый **Module Hub**.
- В Hub добавлены три модуля: **ComfyUI**, **AI Toolkit**, **CorelDRAW**.
- **ComfyUI** открывает текущий рабочий интерфейс 1.1.8 со всеми его функциями и отдельной кнопкой возврата в Hub.
- **CorelDRAW** подключён к уже существующему Corel bridge как beta-модуль. Полная переработка интерфейса Corel остаётся на этапе 3.
- **AI Toolkit** пока показывает подготовленный экран модуля. Реальное управление обучением добавляется на этапе 2.
- Tailscale ON/OFF остаётся только на экране входа.
- Добавлен запрос возможностей сервера: `GET /api/capabilities`.
- Сервер сообщает `server_version`, `api_version`, доступные модули и feature flags.
- Старые API-эндпоинты не переименованы, поэтому архитектура остаётся обратно совместимой.
- Если приложение подключено к Server 6.0, Hub работает в compatibility mode; для feature negotiation нужен Server 6.1.

## Архитектура сервера 6.1

```text
PCRemoteServer.exe
├── Core API / Auth
├── Module Capabilities API
├── ComfyUI API
├── CorelDRAW Bridge
├── File Transfer
├── Tailscale / Network
└── AI Toolkit Bridge (подключение на этапе 2)
```

## Следующий этап

**Этап 2 — AI Toolkit:** проекты, datasets, configs, запуск/остановка training, progress, loss, ETA, logs, checkpoints и переход Test in ComfyUI.
